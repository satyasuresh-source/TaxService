﻿using System;
namespace MunicipalityService.Models
{
    public class Frequency
    {
        public int FrequencyId { get; set; }
        public string Value { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

    }
}
