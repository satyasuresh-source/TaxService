﻿namespace MunicipalityService.Models
{
    public class Tax
    {       
        public int TaxId { get; set; }

        public string TaxValue { get; set; }
        
    }
}
